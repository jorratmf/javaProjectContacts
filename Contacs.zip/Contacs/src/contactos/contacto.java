package contactos;

public class contacto {
	String nombre, direccion, telefono, email;
	
	public contacto(String nombre, String direccion, String telefono, String email) {
		this.nombre = nombre;
		this.direccion = direccion;
		this.telefono = telefono;
		this.email = email;
	}
	
	@Override
	public String toString() {
		return "contacto [nombre=" + this.nombre + ", direccion=" + this.direccion + ", telefono=" + this.telefono + ", email=" + this.email + "]";
	}
}
