package contactos;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.JLabel;
import javax.swing.ImageIcon;
import java.awt.Color;

public class ventana1 {

	private JFrame frmContacto;
	private JTextField fieldNombre;
	private JTextField fieldDireccion;
	private JTextField fieldTelefono;
	private JTextField fieldEmail;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					ventana1 window = new ventana1();
					window.frmContacto.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public ventana1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmContacto = new JFrame();
		frmContacto.getContentPane().setBackground(Color.WHITE);
		frmContacto.setTitle("Contacto");
		frmContacto.setFont(new Font("Calibri", Font.PLAIN, 14));
		frmContacto.setBounds(100, 100, 580, 416);
		frmContacto.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frmContacto.getContentPane().setLayout(null);
		
		JLabel lblNombreIcono = new JLabel("");
		lblNombreIcono.setIcon(new ImageIcon(ventana1.class.getResource("/iconos/name.png")));
		lblNombreIcono.setBounds(10, 40, 40, 40);
		frmContacto.getContentPane().add(lblNombreIcono);
		
		JLabel lblDireccionIcono = new JLabel("");
		lblDireccionIcono.setIcon(new ImageIcon(ventana1.class.getResource("/iconos/home.png")));
		lblDireccionIcono.setBounds(10, 108, 40, 40);
		frmContacto.getContentPane().add(lblDireccionIcono);
		
		JLabel lblTelefonoIcono = new JLabel("");
		lblTelefonoIcono.setIcon(new ImageIcon(ventana1.class.getResource("/iconos/phone.png")));
		lblTelefonoIcono.setBounds(10, 190, 40, 40);
		frmContacto.getContentPane().add(lblTelefonoIcono);
		
		JLabel lblEmailIcono = new JLabel("");
		lblEmailIcono.setIcon(new ImageIcon(ventana1.class.getResource("/iconos/email.png")));
		lblEmailIcono.setBounds(10, 255, 40, 40);
		frmContacto.getContentPane().add(lblEmailIcono);
		
		JLabel lblNombreTexto = new JLabel("Nombre y Apellido");
		lblNombreTexto.setFont(new Font("Calibri", Font.BOLD, 14));
		lblNombreTexto.setBounds(85, 51, 120, 18);
		frmContacto.getContentPane().add(lblNombreTexto);
		
		JLabel lblDireccionTexto = new JLabel("Direcci\u00F3n");
		lblDireccionTexto.setFont(new Font("Calibri", Font.BOLD, 14));
		lblDireccionTexto.setBounds(85, 118, 120, 18);
		frmContacto.getContentPane().add(lblDireccionTexto);
		
		JLabel lblTelefonoTexto = new JLabel("Telefono");
		lblTelefonoTexto.setFont(new Font("Calibri", Font.BOLD, 14));
		lblTelefonoTexto.setBounds(85, 201, 120, 18);
		frmContacto.getContentPane().add(lblTelefonoTexto);
		
		JLabel lblEmailTexto = new JLabel("Email");
		lblEmailTexto.setFont(new Font("Calibri", Font.BOLD, 14));
		lblEmailTexto.setBounds(85, 266, 120, 18);
		frmContacto.getContentPane().add(lblEmailTexto);
		
		fieldNombre = new JTextField();
		fieldNombre.setBounds(215, 48, 282, 20);
		frmContacto.getContentPane().add(fieldNombre);
		fieldNombre.setColumns(10);
		
		fieldDireccion = new JTextField();
		fieldDireccion.setColumns(10);
		fieldDireccion.setBounds(215, 115, 282, 20);
		frmContacto.getContentPane().add(fieldDireccion);
		
		fieldTelefono = new JTextField();
		fieldTelefono.setColumns(10);
		fieldTelefono.setBounds(215, 198, 282, 20);
		frmContacto.getContentPane().add(fieldTelefono);
		
		fieldEmail = new JTextField();
		fieldEmail.setColumns(10);
		fieldEmail.setBounds(215, 263, 282, 20);
		frmContacto.getContentPane().add(fieldEmail);
		
		JButton btnCrear = new JButton("Crear contacto");
		btnCrear.setFont(new Font("Calibri", Font.BOLD, 14));
		btnCrear.setBounds(225, 324, 126, 34);
		frmContacto.getContentPane().add(btnCrear);
		
		btnCrear.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent evt) {
				contacto c = new contacto(fieldNombre.getText(), fieldDireccion.getText(), fieldTelefono.getText(), fieldEmail.getText());
				System.out.println(c);
				fieldNombre.setText("");
				fieldDireccion.setText("");
				fieldTelefono.setText("");
				fieldEmail.setText("");
			}
		});
	}
}
